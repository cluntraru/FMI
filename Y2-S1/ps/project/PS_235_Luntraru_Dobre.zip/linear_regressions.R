library(tidyverse)
library(ggplot2)

message(cat("LINEAR REGRESSIONS"))
#plot(swiss$Agriculture, swiss$Education)

scatter.smooth(x = swiss$Education, y = swiss$Agriculture, main = "Education ~ Agriculture")


dev.new()
ggplot(swiss,aes(x = Education, y = Agriculture)) +
geom_point() + 
stat_smooth(method = lm)

dev.new()
ggplot(swiss,aes(x = Education, y = Catholic)) +
  geom_point() + 
  stat_smooth(method = lm)

dev.new()
ggplot(swiss,aes(x = Agriculture, y = Catholic)) +
  geom_point() + 
  stat_smooth(method = lm)

message(cat("SIMPLE LINEAR REGRESSION EDUCATION ~ AGRICULTURE PROPERTIES:"))
summary(lm(swiss$Education ~ swiss$Agriculture))

message(cat("MULTIPLE LINEAR REGRESSION EDUCATION ~ AGRICULTURE + CATHOLIC PROPERTIES:"))
summary(lm(swiss$Education ~ swiss$Agriculture+swiss$Catholic))

message(cat("AS WE CAN SEE, THE P-VALUE OF THE FIRST REGRESSION IS LOWER AND THE T VALUE IS HIGHER, MEANING THE FIRST REGRESSION IS A BETTER FIT"))
message(cat("IT WAS EXPECTED THAT THERE WOULD BE A STRONGER CORRELATION BETWEEN EDUCATION AND AGRICULTURE THAN BETWEEN EDUCATION AND RELIGION"))
