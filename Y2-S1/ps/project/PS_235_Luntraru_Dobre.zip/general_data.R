attach(swiss)


colNames <- colnames(swiss)

message(cat("MEANS AND VARIANCES OF ALL PROPERTIES\n"))
colNumber <- 1
for(colName in colNames)
{
  currCol <- swiss[, colNumber:colNumber]
  message(cat("The mean of", colName, "is", mean(currCol),
            "and the variance of", colName, "is", var(currCol)))
  colNumber <- colNumber + 1
}
message(cat("\n"))

message(cat("QUARTILES OF ALL PROPERTIES\n"))
colNumber <- 1
for(colName in colNames)
{
  currCol <- swiss[, colNumber:colNumber]
  message(cat("The quartiles of", colName, "are:\n"))
  print(quantile(currCol))
  message("\n")
  colNumber <- colNumber + 1
}

boxplot(swiss)

message(cat("We can see in the boxplot that while all the other statistics seem evenly distributed, there are a lot of regions with a small number of catholics"))

