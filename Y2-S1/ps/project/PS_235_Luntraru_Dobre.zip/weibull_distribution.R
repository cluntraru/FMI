# Alegem o perioada pe care sa aplicam repartitia Weibull
perioada <- seq(0, 5, 0.001)

# Vrem cele 2 ploturi pe o singura linie, pe 2 coloane
par(mfrow = c(1, 2))

# Cream un plot pentru densitatea de probabilitate pe care o limitam la y = 2.5. Mai sus
# de atat, doar ne micsoreaza prea mult liniile si nu ofera informatii utile
plot(perioada, dweibull(perioada, 0.5), type = "l", main = "Densitatea de probabilitate", 
     xlab="x", ylab = "Rata de esuare", ylim = c(0, 2.5))

# Adaugam densitatile pentru diferiti parametri "shape" care dicteaza monotonia ratei
# de crestere
lines(perioada, dweibull(perioada, 1), type = "l", col = "red")
lines(perioada, dweibull(perioada, 2), type = "l", col = "purple")
lines(perioada, dweibull(perioada, 5), type = "l", col = "green")

# Cream un plot pentru functia de repartitie, pastrand culorile folosite la densitate
plot(perioada, pweibull(perioada, 0.5), type = "l", main = "Functia de repartitie", 
     xlab = "x", ylab = "P(X <= x)", ylim = c(0, 1))

# Analog cu densitatea de probabilitate, pastram culorile
lines(perioada, pweibull(perioada, 1), type = "l", col = "red")
lines(perioada, pweibull(perioada, 2), type = "l", col = "purple")
lines(perioada, pweibull(perioada, 5), type = "l", col = "green")
